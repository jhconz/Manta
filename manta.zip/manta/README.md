# Manta actuator controller

| Folder | Runs on | What it is |
|---|---|---|
| `pico/` | Raspberry Pi Pico (MicroPython) | `robot_io.py` firmware: 4 belt actuators + ballast, UART protocol 2.2, safety cut-offs, drive PWM limit. See `pico/README.md` and `pico/PROTOCOL_CHANGES.md`. |
| `pi/` | Raspberry Pi | Touchscreen GUI (`manta_gui.py`) and its UART link, protocol and storage modules. See `pi/README.md`. |
| `pi/tests/` | Any PC | Runs the real firmware in-process against the real host link (`sim_pico.py`). `python3 pi/tests/test_link.py` (needs `pyserial`); `test_smooth.py` and `gui_shots.py` need matplotlib / a display. |

## Quick start

Pico: copy `pico/robot_io.py` to the board (save it as `main.py` to run at power-up).

Pi:
```
pip install pyserial
python3 pi/manta_gui.py
```
