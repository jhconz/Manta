# Manta controller (Raspberry Pi side)

Touchscreen GUI for the Pico running `robot_io.py`, protocol **2.2** (an older 2.x Pico still works, minus the newer features).

## Files

| File | What it does |
|---|---|
| `manta_gui.py` | The app: run this one |
| `pico_protocol.py` | Every command, status and error code; frame builders; the stream parser (handles the raw log block); log decoding. No serial or GUI code |
| `pico_link.py` | Serial link: an RX thread parses everything; a worker thread sends one command at a time and matches its reply; `send_now()` for STOP |
| `host_storage.py` | Preset library (`~/.manta/presets.json`), sequence logs (`~/manta_logs/`, CSV export), controller settings (`~/.manta/settings.json`: active sequence, cycles, descend depth) |
| `numpad.py` | Your existing keypad. Optional: a simple built-in keypad is used if it's missing |

## Setup

```
pip install pyserial
python3 manta_gui.py
```
UART: `/dev/serial0` (GPIO14 TX, GPIO15 RX), 115200 8N1, wired to Pico GP13 (RX) / GP12 (TX).
For full screen, uncomment `root.attributes('-fullscreen', True)` in `MantaGUI.__init__`.

## Screens

- **Top bar (always visible):** link status + Pico protocol version, battery, **STOP** (sent at once, skipping the queue), **POWER DOWN** (confirm → return to zero → positions → purge → "switch off main power").
- **PRIMARY** (opens first):
  - **Active sequence:** tap a preset to make it active (remembered across restarts), set its cycles, **START SEQUENCE**. If the Pico's presets are out of sync with this controller, it asks before running.
  - **RETURN TO ZERO** drives every motor with a known zero back to it. Badges show which zeros are known; it warns first if some aren't.
  - **Ballast:** a gauge shows the wiper, the neutral point (N) and the descend target (D). **DESCEND** fills to neutral + the descend depth (SETTINGS), **NEUTRAL** goes to the stored neutral, **PURGE** empties it. These and RETURN TO ZERO lock the controls until the Pico reports the end (ABORT = STOP).
- **SEQUENCE:** duty % / latent / phase for M1–M4, period, cycles.
  - **RUN NOW** loads the sequence into the Pico's temporary slot (0xFE) and runs it. Controls are locked until the log arrives (ABORT = STOP).
  - **SAVE TO PRESET** writes it to a slot (0–253) with a name. It asks before overwriting a slot this controller knows about.
- **MANUAL:** ◀ REV / ■ STOP / FWD ▶ per motor at the speed % shown (10 % = run slow). Motors run until STOP; the GUI re-sends the command every second (the Pico stops a motor 3 s after the last one). SET ZERO per motor or ZERO ALL. Positions in degrees and counts, and whether each motor's zero is known. Positions refresh every second while this tab is open.
  - **Ballast row:** ◀ EMPTY / ■ STOP / FILL ▶ (Pico default 40 %, stops by itself at the empty and full limits), the wiper reading, and **SET NEUTRAL**, which stores the current position on the Pico as neutral buoyancy.
- **FILES:**
  - **Presets:** LOAD into the editor, RUN, DELETE (here and on the Pico). CHECK SYNC compares the Pico's preset count + CRC with this library; PUSH ALL TO PICO replaces the Pico's presets with these.
  - **Logs:** each sequence's log is saved automatically when it arrives. FETCH LAST, EXPORT CSV (counts and degrees from the start), DELETE.

- **SETTINGS:**
  - **Ballast PID** and **Return-to-zero PID** (Kp / Ki / Kd): READ from the Pico, APPLY saves them on the Pico.
  - **Slip limits** per motor in degrees (0 = off): READ / APPLY, saved on the Pico.
  - **Drive PWM limit** (default 80 %): READ / APPLY, saved on the Pico, which enforces it for all drive motion. The SEQUENCE duty fields and the MANUAL speed can't be set above it; lowering it pulls existing values down. Stored presets above it run at the limit (PRIMARY > START says so).
  - **Descend depth %:** how far past neutral DESCEND fills (default 5 % of the travel). Saved on this controller.
  - All Pico values are read automatically at start-up.

## Behaviour notes

- At start-up the GUI pings the Pico (and warns on a protocol major-version mismatch), checks preset sync, and reads positions.
- If the Pico boots after an unclean shutdown, a dialog lists the motors whose zero is unknown. Re-zero them on MANUAL.
- Driver faults raise a dialog. Slip cuts and manual-move endings show on the status line.
- Battery warnings and the critical shutdown work as in the old GUI.

## To do

- **Pico side: overwrite permission.** PRESET_DEFINE overwrites a slot silently. Make the Pico refuse unless the frame asks to overwrite (new error, e.g. 0x0C), so it bounces back for permission. The GUI's check uses only its own library, which can be out of date. Marked `TODO(slave side)` in `SequenceTab.on_save`.
- Descend depth is a placeholder (5 %): set it once the real neutral and dive behaviour are known.
- The old LED code (GPIO 13) is not carried over; not needed for this version.
