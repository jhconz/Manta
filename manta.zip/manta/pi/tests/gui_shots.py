"""Drive the GUI against the simulated Pico and take screenshots (run under xvfb-run)."""
import sys, os, subprocess, shutil, tkinter as tk
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sim_pico
from pico_link import PicoLink
from host_storage import PresetLibrary, LogStore
import manta_gui as G
import pico_protocol as P

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'shots')
shutil.rmtree(OUT, ignore_errors=True); os.makedirs(OUT)
shutil.rmtree('/tmp/claude_sim_gui', ignore_errors=True)
link = PicoLink(serial_obj=sim_pico.HostSerial())
root = tk.Tk()
app = G.MantaGUI(root, link=link,
                 library=PresetLibrary('/tmp/claude_sim_gui/host/presets.json'),
                 logs=LogStore('/tmp/claude_sim_gui/host/logs'))
state = {}

def shot(name):
    root.update(); subprocess.run(['import', '-window', 'root', os.path.join(OUT, name + '.png')])
    print('shot', name, '|', app.status_var.get())

def boot():
    _, io, st = sim_pico.start('/tmp/claude_sim_gui/pico'); state['io'] = io
def define():
    app.close_dialog('boot')
    t = app.tab_seq
    vals = [('80', '0.00', '0.00'), ('80', '0.10', '0.00'), ('60', '0.00', '1.00'), ('60', '0.20', '1.00')]
    for v, (d, l, p) in zip(t.vars, vals):
        v['duty'].set(d); v['latent'].set(l); v['phase'].set(p)
    t.period.set('0.60'); t.cycles.set('2')
    t.slot.set('3'); t.name.set('Cruise')
    t.on_save()
def save_second():
    t = app.tab_seq; t.slot.set('7'); t.name.set('Turn left'); t.vars[0]['duty'].set('30'); t.on_save()
def overwrite_prompt():
    t = app.tab_seq; t.slot.set('3'); t.name.set('Cruise v2'); t.on_save()
def cancel_confirm():
    app.close_dialog('confirm')
def run_now():
    app.tab_seq.on_run()
def files_tab():
    app.nb.select(2)
    first = app.tab_files.ltree.get_children()
    if first: app.tab_files.ltree.selection_set(first[0])
    app.tab_files.ptree.selection_set('3')
def manual_tab():
    app.nb.select(1)
    app.tab_man.on_move(0, P.MANUAL_FORWARD)
    app.tab_man.speed.set('30'); app.tab_man.on_move(2, P.MANUAL_REVERSE)
def manual_stop():
    app.tab_man.on_halt(0); app.tab_man.on_halt(2)
def zero_all():
    app.tab_man.on_zero(0x0F)
def confirm_yes():
    dlg = app._dialogs.get('confirm')
    if dlg:   # press YES
        for w in dlg.winfo_children():
            for b in w.winfo_children():
                if isinstance(b, G.ttk.Button) and b.cget('text') == 'YES':
                    b.invoke()

plan = [(200, boot), (2500, lambda: shot('1_boot_zero_unknown')), (2800, define),
        (3300, save_second), (3800, overwrite_prompt), (4300, lambda: shot('2_overwrite_prompt')),
        (4500, cancel_confirm), (4700, run_now), (5300, lambda: shot('3_running')),
        (9000, files_tab), (9500, lambda: shot('4_files')),
        (9800, manual_tab), (11500, lambda: shot('5_manual_running')),
        (11700, manual_stop), (12500, zero_all), (12800, confirm_yes),
        (14000, lambda: shot('6_manual_zeroed')), (14300, root.destroy)]
for t, fn in plan:
    root.after(t, fn)
root.mainloop()
print('library:', {k: v['name'] for k, v in app.lib.presets.items()}, '| pico sync:', app.pico_sync,
      '| lib crc %04X' % app.lib.crc())
