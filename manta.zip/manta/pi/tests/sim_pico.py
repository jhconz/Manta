"""Test harness: run the real firmware (robot_io.py) in-process, in real time,
on stub hardware, wired to the host through a fake serial pair."""
import sys, types, threading, time, os

FW_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'pico')

class Pipe:
    def __init__(self):
        self.buf = bytearray(); self.lock = threading.Lock(); self.cv = threading.Condition(self.lock)
    def put(self, b):
        with self.cv:
            self.buf.extend(bytes(b)); self.cv.notify_all()
    def take(self, n=None, timeout=0.0):
        with self.cv:
            if not self.buf and timeout:
                self.cv.wait(timeout)
            n = len(self.buf) if n is None else min(n, len(self.buf))
            out = bytes(self.buf[:n]); del self.buf[:n]; return out
    def size(self):
        with self.lock:
            return len(self.buf)

to_pico, to_host = Pipe(), Pipe()

class HostSerial:
    """What the host's PicoLink sees (pyserial-like)."""
    def write(self, b): to_pico.put(b)
    def read(self, n): return to_host.take(n, timeout=0.05)
    def close(self): pass

state = {'flt': {2: 1, 7: 1, 10: 1}, 'batt_raw': 45018, 'pot': 30000.0, 'jam': set()}
sms = {}

def install_stubs():
    m = types.ModuleType('machine')
    class Pin:
        IN = OUT = PULL_UP = PULL_DOWN = 0
        def __init__(s, n=None, *a, **k): s.n = n; s.v = k.get('value', 0)
        def value(s, v=None):
            if v is None:
                return state['flt'].get(s.n, 1)
            s.v = v
    class PWM:
        def __init__(s, pin): s.d = 0
        def freq(s, f): pass
        def duty_u16(s, d): s.d = d
    class UART:
        def __init__(s, *a, **k): pass
        def write(s, b): to_host.put(b)
        def any(s): return to_pico.size()
        def read(s): return to_pico.take() or None
        def flush(s): pass
    class ADC:
        def __init__(s, ch): s.ch = ch
        def read_u16(s):
            return int(state['pot']) if s.ch == 28 else state['batt_raw']
    def deepsleep():
        state['asleep'] = True
        raise SystemExit
    m.Pin, m.PWM, m.UART, m.ADC, m.deepsleep = Pin, PWM, UART, ADC, deepsleep
    rp2 = types.ModuleType('rp2')
    class PIO: SHIFT_LEFT = 0; SHIFT_RIGHT = 1
    rp2.PIO = PIO
    rp2.asm_pio = lambda **k: (lambda f: f)
    class SM:
        def __init__(s, sm_id, *a, **k): s.c = 0.0; sms[sm_id] = s
        def active(s, v): pass
        def rx_fifo(s): return 0
        def get(s): return int(round(s.c)) & 0xFFFFFFFF
    rp2.StateMachine = SM
    th = types.ModuleType('_thread')
    th.allocate_lock = threading.Lock
    th.start_new_thread = lambda f, a: threading.Thread(target=f, args=a, daemon=True).start()
    sys.modules.update(machine=m, rp2=rp2, _thread=th)
    # MicroPython's extra time functions on the real time module
    time.ticks_ms = lambda: int(time.monotonic() * 1000)
    time.ticks_us = lambda: int(time.monotonic() * 1_000_000)
    time.ticks_diff = lambda a, b: a - b
    time.ticks_add = lambda a, b: a + b
    time.sleep_ms = lambda ms: time.sleep(ms / 1000)
    time.sleep_us = lambda us: time.sleep(us / 1_000_000)

def physics(io):
    """Motors: 5000 counts/s at full duty, nothing below 4 %. Ballast: 2000 raw/s at the cap."""
    last = time.monotonic()
    while not state.get('asleep'):
        time.sleep(0.002)
        now = time.monotonic(); dt = now - last; last = now
        for i, mot in enumerate(io.motors):
            duty = mot.pwm.d / 65535
            sp = 0 if duty < 0.04 or i in state['jam'] else duty * (-1 if mot.dir.v else 1)
            if mot.enc:
                mot.enc._sm.c += 5000 * sp * dt
        b = io.ballast; duty = b.pwm.d / 65535
        if duty >= 0.10:
            state['pot'] = max(0, min(65535, state['pot'] + 2000 * duty / 0.65 * (-1 if b.dir.v else 1) * dt))

def start(workdir):
    os.makedirs(workdir, exist_ok=True)
    os.chdir(workdir)
    install_stubs()
    sys.path.insert(0, FW_DIR)
    import robot_io
    io = robot_io.RobotIO()
    threading.Thread(target=physics, args=(io,), daemon=True).start()
    threading.Thread(target=io.run, daemon=True).start()
    return HostSerial(), io, state
