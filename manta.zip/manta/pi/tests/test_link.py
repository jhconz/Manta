"""End-to-end: host protocol + link against the real firmware on stub hardware."""
import os, sys, time, threading, shutil
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sim_pico
shutil.rmtree('/tmp/claude_sim_link', ignore_errors=True)
ser, io, st = sim_pico.start('/tmp/claude_sim_link')

import pico_protocol as P
from pico_link import PicoLink
from host_storage import PresetLibrary, LogStore

events = []
lock = threading.Lock()
def on_msg(m):
    with lock:
        events.append(m)
def take_events():
    with lock:
        out = list(events); events.clear(); return out
def fmt(m):
    if isinstance(m, P.LogBlock):
        return 'LOG(%d B, crc %s)' % (len(m.raw), 'OK' if m.crc_ok else 'BAD')
    names = {P.ST_ACK:'ACK', P.ST_DONE:'DONE', P.ST_ERROR:'ERR', P.ST_PONG:'PONG', P.ST_EVENT:'EVENT',
             P.ST_PRESET_SYNC:'SYNC', P.ST_POSITION:'POS', P.ST_BOOT:'BOOT', P.ST_PID_GAIN:'PID'}
    return '%s(%02x %02x %02x)' % (names.get(m.status, hex(m.status)), m.i1, m.i2, m.i3)
def check(label, cond):
    print(('PASS ' if cond else 'FAIL ') + label)
    return cond

link = PicoLink(serial_obj=ser, on_message=on_msg)
time.sleep(0.6)
boot = take_events()
print('boot messages:', [fmt(m) for m in boot])
check('boot: F2 sync, F7 boot (unclean, none restored), EVENT RTZ zero-unknown',
      [m.status for m in boot] == [P.ST_PRESET_SYNC, P.ST_BOOT, P.ST_EVENT]
      and boot[1].i1 == 0 and boot[1].i2 == 0 and boot[2].i1 == P.EV_RTZ and boot[2].i2 == 6)

r = link.call(P.ping(), P.wait_pong)
check('ping -> version 2.2', r.ok and (r.first(P.ST_PONG).i1, r.first(P.ST_PONG).i2) == (2, 2))

lib = PresetLibrary('/tmp/claude_sim_link/host/presets.json'); lib.clear()
motors = [(65535, 0.0, 0.0), (65535, 0.1, 0.0), (40000, 0.0, 1.0), (40000, 0.2, 1.0)]
r = link.call(P.preset_define(16, 0.5, motors))
lib.put(16, 'test', 0.5, motors, 2)
d = r.first(P.ST_DONE)
check('define preset 16 -> DONE id 16, count 1 (16 = 0x10 no longer looks like an event)', r.ok and d.i1 == 16 and d.i2 == 1)
take_events()
r = link.call(P.preset_sync(), P.wait_sync)
s = r.first(P.ST_PRESET_SYNC)
check('sync: count 1, CRC matches host library (%04X)' % lib.crc(), s.i1 == 1 and P.u16(s) == lib.crc())

r = link.call(P.preset_run(16, 2), done=None, ack_grace=0.15)
check('run preset 16 accepted', r.ok)
t0 = time.time(); got = []
while time.time() - t0 < 8:
    got += take_events()
    if any(isinstance(m, P.LogBlock) for m in got): break
    time.sleep(0.05)
ev = [m for m in got if isinstance(m, P.Frame) and m.status == P.ST_EVENT]
logs = [m for m in got if isinstance(m, P.LogBlock)]
check('sequence: EVENT 0x10 then log block, CRC ok', ev and ev[0].i1 == P.EV_SEQUENCE and logs and logs[0].crc_ok)
hdr, smp = P.decode_log(logs[0].raw)
print('   log:', hdr['n_samples'], 'samples @', hdr['interval_ms'], 'ms, preset', hdr['preset'], P.flags_text(hdr['flags']))
store = LogStore('/tmp/claude_sim_link/host/logs'); name = store.save(logs[0].raw)
csv = store.export_csv(name)
check('log saved + CSV exported (%s)' % name, open(csv).read().count('\n') == hdr['n_samples'] + 2)

r = link.call(P.log_get(), P.wait_log, timeout=8)
check('LOG_GET -> same log again', r.ok and r.log.crc_ok and r.log.raw == logs[0].raw)

r = link.call(P.preset_run(99, 1), done=None)
check('run unknown preset -> error "unknown preset"', not r.ok and r.error_text() == 'unknown preset')

take_events()
r = link.call(P.manual(0, P.MANUAL_FORWARD))
check('manual M1 forward (default 10 %%) -> DONE, duty %.2f' % (io.m1.pwm.d / 65535), r.ok and abs(io.m1.pwm.d/65535 - 0.10) < 0.01)
for _ in range(2):
    time.sleep(1.0); link.call(P.manual(0, P.MANUAL_FORWARD))      # keepalive
r = link.call(P.manual(0, P.MANUAL_STOP), P.wait_done_then_position)
idx, cnt, _ = P.position(r.first(P.ST_POSITION))
check('manual stop -> DONE + position M1 = %d (≈ 2 s x 500 counts/s)' % cnt, r.ok and idx == 0 and 800 < cnt < 1200)

r = link.call(P.manual(1, P.MANUAL_REVERSE, int(0.3 * 65535)))
time.sleep(3.4)
ev = [m for m in take_events() if isinstance(m, P.Frame)]
end = [m for m in ev if m.status == P.ST_EVENT and m.i1 == P.EV_MANUAL]
check('M2 at 30 %% without keepalive -> EVENT manual-end (timeout) + position',
      end and end[0].i2 == 1 and end[0].i3 == 1 and any(m.status == P.ST_POSITION for m in ev))

r = link.call(P.set_zero(0x0F))
check('set zero all -> DONE known mask 1111', r.ok and r.first(P.ST_DONE).i1 == 0x0F)
r = link.call(P.get_positions())
pos = [P.position(f)[1] for f in r.frames(P.ST_POSITION)]
check('get positions -> 4 x F6 + DONE: %s' % pos, r.ok and len(pos) == 4 and all(abs(p) <= 2 for p in pos))

r = link.call(P.ballast_pid(0), P.wait_pid)
gains = [((f.i2 << 8) | f.i3) / 100 for f in r.frames(P.ST_PID_GAIN)]
check('ballast PID query -> %s' % gains, r.ok and gains == [15.0, 1.0, 0.2])

# STOP bypassing the queue while a manual motor runs
link.call(P.manual(2, P.MANUAL_FORWARD)); time.sleep(0.3)
link.send_now(P.stop()); time.sleep(0.2)
check('STOP (send_now) stops M3', io.m3.pwm.d == 0)

# move motors off zero, then a normal power-down
for i, a in ((0, P.MANUAL_FORWARD), (3, P.MANUAL_REVERSE)):
    link.call(P.manual(i, a, int(0.5 * 65535)))
time.sleep(0.6)
for i in (0, 3):
    link.call(P.manual(i, P.MANUAL_STOP), P.wait_done_then_position)
take_events()
r = link.call(P.powerdown(), P.wait_done, timeout=90)
seq = [fmt(m) for m in r.msgs]
print('   powerdown reply:', seq)
for _ in range(50):                                   # the firmware sleeps just after its final DONE
    if st.get('asleep'):
        break
    time.sleep(0.05)
check('powerdown -> EVENT RTZ ok, 4 x POS, EVENT purge, final DONE; Pico asleep',
      r.ok and r.msgs[0].status == P.ST_EVENT and r.msgs[0].i1 == P.EV_RTZ and r.msgs[0].i2 == 0
      and sum(1 for m in r.msgs if m.status == P.ST_POSITION) == 4 and st.get('asleep'))
