"""Smooth-step sequence waveform: checks against the old square wave, then a
real run on the simulated Pico with the PWM / DIR writes recorded.
Run: python3 test_smooth.py   (writes shots/smooth_vs_square.png)"""
import os, sys, time, threading
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import sim_pico
import pico_protocol as P
from pico_link import PicoLink

results = []
def check(name, ok):
    results.append(ok)
    print(('PASS ' if ok else 'FAIL ') + name)

ser, io, st = sim_pico.start('/tmp/claude_sim_smooth')
time.sleep(1.5)
R = type(io)

# ---------------------------------------------------------------- the curve
f = R.smooth_step
h = 1e-6
check('smooth_step: f(0)=0, f(0.5)=0.5, f(1)=1',
      f(0.0) == 0 and abs(f(0.5) - 0.5) < 1e-12 and f(1.0) == 1)
check('smooth_step: slope 0 at both ends (%.2g, %.2g), peak slope 1.875 at 0.5 (%.4f)'
      % ((f(h) - f(0)) / h, (f(1) - f(1 - h)) / h, (f(0.5 + h) - f(0.5 - h)) / (2 * h)),
      abs((f(h) - f(0)) / h) < 1e-5 and abs((f(1) - f(1 - h)) / h) < 1e-5
      and abs((f(0.5 + h) - f(0.5 - h)) / (2 * h) - 1.875) < 1e-4)
check('smooth_step: curvature 0 at both ends', abs((f(2 * h) - 2 * f(h) + f(0)) / h ** 2) < 1e-3
      and abs((f(1) - 2 * f(1 - h) + f(1 - 2 * h)) / h ** 2) < 1e-3)
check('smooth_step: point-symmetric f(x) + f(1-x) = 1',
      all(abs(f(x / 100) + f(1 - x / 100) - 1) < 1e-12 for x in range(101)))
check('matches the Abaqus formula 10x^3 - 15x^4 + 6x^5',
      all(abs(f(x / 50) - (10 * (x / 50) ** 3 - 15 * (x / 50) ** 4 + 6 * (x / 50) ** 5)) < 1e-12
          for x in range(51)))

# ---------------------------------------------------------------- schedules
def sample(tracks, T, dt=1e-4):
    out = []
    for pts in tracks:
        k, vals = 0, []
        for n in range(int(T / dt) + 2):
            v, k = io._track_value(pts, k, n * dt)
            vals.append(v)
        out.append(vals)
    return out

def build(sched, cycles, ramp):
    old = R.SMOOTH_STEP_S
    R.SMOOTH_STEP_S = ramp
    try:
        return io._build_motion_schedule(sched, cycles)
    finally:
        R.SMOOTH_STEP_S = old

cases = {
    'latent 0, phases 0 / 0.5 / -1 / 0.25': {'period': 0.6, 'motors': [
        (65535, 0.0, 0.0), (32768, 0.0, 0.5), (49152, 0.0, -1.0), (20000, 0.0, 0.25)]},
    'latent 0.3 / 0.6 / 0.9 / 0': {'period': 0.6, 'motors': [
        (65535, 0.3, 0.0), (65535, 0.6, 0.0), (65535, 0.9, 0.0), (65535, 0.0, 1.0)]},
    'short period 0.2 s (ramps cut to fit)': {'period': 0.2, 'motors': [
        (65535, 0.0, 0.0), (65535, 0.5, 0.3), (0, 0.0, 0.0), (65535, 0.0, -0.4)]},
}
dt = 1e-4
for name, sched in cases.items():
    sq, Tsq = build(sched, 3, 0.0)
    sm, Tsm = build(sched, 3, R.SMOOTH_STEP_S)
    T = max(Tsq, Tsm) + 0.01
    a, b = sample(sq, T, dt), sample(sm, T, dt)
    step_n = int(R.SEQ_UPDATE_US / 1e6 / dt)
    max_jump_sq = max(max(abs(v[n + step_n] - v[n]) for n in range(len(v) - step_n)) for v in a)
    max_jump_sm = max(max(abs(v[n + step_n] - v[n]) for n in range(len(v) - step_n)) for v in b)
    # flips of DIR while the duty is not ~0
    flips = sum(1 for v in b for n in range(len(v) - 1) if v[n] * v[n + 1] < 0
                and max(abs(v[n]), abs(v[n + 1])) > 0.01)
    # stroke areas (travel): signed running integral, compared at its extremes
    def strokes(v):
        out, acc, cur = [], 0.0, None
        for x in v:
            s = (x > 0) - (x < 0)
            if s and s != cur:
                if cur is not None:
                    out.append(acc)
                acc, cur = 0.0, s
            acc += x * dt
        if cur is not None:
            out.append(acc)
        return out
    area_err = 0.0
    for va, vb in zip(a, b):
        sa, sb = strokes(va), strokes(vb)
        if len(sa) != len(sb):
            area_err = float('inf')
            break
        for x, y in zip(sa, sb):
            area_err = max(area_err, abs(x - y) / max(abs(x), 1e-9))
    net = max(abs(sum(v) * dt) for v in b)
    print('   %s: square %.3f s, smooth %.3f s' % (name, Tsq, Tsm))
    check('%s: biggest change per 2 ms update %.3f (square wave %.3f)' % (name, max_jump_sm, max_jump_sq),
          max_jump_sm < 0.25 * max_jump_sq)
    check('%s: no DIR flip at non-zero duty (%d)' % (name, flips), flips == 0)
    check('%s: every stroke\'s travel unchanged (worst %.2g %%)' % (name, area_err * 100), area_err < 0.005)
    check('%s: still ends where it started (net %.2g)' % (name, net), net < 1e-3)
    check('%s: run is at most one ramp longer (%.3f -> %.3f s)' % (name, Tsq, Tsm),
          Tsq <= Tsm <= Tsq + R.SMOOTH_STEP_S + 1e-9)

# ---------------------------------------------------------------- real run in the simulator
rec = []
lock = threading.Lock()
t0 = [None]
def hook(i, m):
    pwm, d = m.pwm, m.dir
    orig_duty = pwm.duty_u16
    def duty(v):
        orig_duty(v)
        with lock:
            if t0[0] is not None:
                rec.append((time.monotonic() - t0[0], i, v / 65535 * (-1 if d.v else 1)))
    pwm.duty_u16 = duty
for i, m in enumerate(io.motors):
    hook(i, m)

link = PicoLink(None, serial_obj=ser, on_message=lambda m: None)
sched = cases['latent 0, phases 0 / 0.5 / -1 / 0.25']
motors = [(d, l, p) for d, l, p in sched['motors']]
traces = {}
for label, ramp in (('square', 0.0), ('smooth', R.SMOOTH_STEP_S)):
    R.SMOOTH_STEP_S = ramp
    with lock:
        rec.clear()
    c0 = [m.count for m in io.motors]
    t0[0] = time.monotonic()
    r = link.call(P.preset_define(0xFE, sched['period'], motors), timeout=2)
    r = link.call(P.preset_run(0xFE, 2), P.wait_log, timeout=15)
    with lock:
        traces[label] = list(rec)
        t0[0] = None
    peaks = [m.count - c for m, c in zip(io.motors, c0)]
    traces[label + '_ok'] = r.ok
    print('   %s run: %d PWM writes, ok=%s, net counts %s' % (label, len(traces[label]), r.ok, peaks))
    time.sleep(0.3)
R.SMOOTH_STEP_S = 0.080

def max_dir_flip_duty(tr):
    """Largest duty on either side of a DIR change, per motor."""
    worst, last = 0.0, {}
    for t, i, v in tr:
        p = last.get(i)
        if p is not None and p * v < 0:
            worst = max(worst, abs(p), abs(v))
        if v != 0:
            last[i] = v
    return worst
check('simulator run, square wave: DIR flips at duty up to %.2f' % max_dir_flip_duty(traces['square']),
      traces['square_ok'])
check('simulator run, smooth step: DIR flips at duty ≤ %.3f, sequence + log complete'
      % max_dir_flip_duty(traces['smooth']),
      traces['smooth_ok'] and max_dir_flip_duty(traces['smooth']) < 0.02)

# ---------------------------------------------------------------- plot
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig, axes = plt.subplots(2, 1, figsize=(9, 5.2), sharex=True)
names = ['M1 (100 %, phase 0)', 'M2 (50 %, phase 0.5)']
for ax, i in zip(axes, (0, 1)):
    for label, style, col in (('square', '-', '#bbbbbb'), ('smooth', '-', '#2a6fdb')):
        pts = [(t, v) for t, j, v in traces[label] if j == i]
        xs, ys = [], []
        for t, v in pts:                                   # draw as held values
            if ys:
                xs.append(t); ys.append(ys[-1])
            xs.append(t); ys.append(v)
        ax.plot(xs, ys, style, color=col, lw=1.8 if label == 'smooth' else 1.4,
                label='square wave (before)' if label == 'square' else 'smooth step, %.0f ms ramps (now)' % (R.SMOOTH_STEP_S * 1000))
    ax.axhline(0, color='#888', lw=0.6)
    ax.set_ylabel('duty (+fwd / -rev)')
    ax.set_title(names[i], fontsize=10, loc='left')
    ax.set_ylim(-1.1, 1.1)
    ax.grid(alpha=0.25)
axes[0].legend(loc='upper right', fontsize=8, frameon=False)
axes[1].set_xlabel('time (s), PWM as written by the Pico in the simulator: period 0.6 s, 2 cycles')
fig.tight_layout()
SHOTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'shots')
os.makedirs(SHOTS, exist_ok=True)
fig.savefig(os.path.join(SHOTS, 'smooth_vs_square.png'), dpi=110)
print('%d/%d passed' % (sum(results), len(results)))
os._exit(0 if all(results) else 1)
