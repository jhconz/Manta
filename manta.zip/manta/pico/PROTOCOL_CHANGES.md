# UART protocol changes: Pico firmware (`robot_io.py`)

What the host side of the UART has to know about each firmware change.
Add an entry at the top of the change log every time the firmware changes
anything the host can see: wiring, frames, codes, timing or unsolicited messages.

**Current protocol version: 2.2** (returned by PING, see below)
**Previous versions:** 2.1 (same, minus DUTY_LIMIT), 2.0 (minus the 2.1 additions below), 1.0 (`onboard_pi.py`, 2-motor manta controller)

---

## Host update checklist for 2.1 → 2.2 (additive)

- [ ] New command **0x17 DUTY_LIMIT**: query / set the drive-motor PWM limit (default 80 %). Read it at start-up and keep duty inputs at or below it.
- [ ] The Pico enforces the limit itself: preset duties above it run at the limit (no error), and manual speeds and return-to-zero are capped too.

## Host update checklist for 2.0 → 2.1 (all additive; a 2.0 host keeps working)

- [ ] New commands **0x14 RETURN_TO_ZERO**, **0x15 SLIP_LIMIT**, **0x16 RTZ_PID** (table below).
- [ ] **GET_POSITIONS** now sends an `F8` ballast frame after the four `F6` frames, before DONE.
- [ ] **MANUAL motor index 4 is the ballast:** forward fills, reverse empties, default 40 % duty. Its stop is followed by `F8` (not `F6`), and it can end on its own with `EVENT 0x14 4 4` at a soft limit.
- [ ] Accept status **0xF8 BALLAST** and **0xF9 SLIP**. `F3` frames with info1 `0x10`–`0x12` are return-to-zero gains.
- [ ] Slip limits and return-to-zero gains are now saved in `settings.json` and survive power cycles.

## Host update checklist for 1.0 → 2.0

- [ ] **Rewire UART:** Pico TX is now **GP12**, RX is **GP13** (was GP16 / GP17). Still 115200 baud, 8N1.
- [ ] Accept **unsolicited** frames at any time, not only as replies: `0xF2` PRESET_SYNC (sent at every boot) and `0x03 0x20` driver fault, in addition to the existing `0xF0` / `0xF1` battery messages.
- [ ] On `0xF2` at boot: compare count + CRC with the host's own preset table and resend presets if they differ (procedure below).
- [ ] PONG now carries the protocol version in info1/info2. Check it after connecting.
- [ ] GET_STATUS reply: info2 = fault bits, info3 = preset count (both were always 0).
- [ ] New commands 0x08–0x0B (presets), new error codes 0x06–0x09 and 0x20.
- [ ] PRESET_DEFINE / PRESET_DELETE of a *stored* preset are refused with `ERR_BUSY` while a sequence runs. Define stored presets before running them.
- [ ] Use id **0xFE** for one-off sequences (temporary slot, see below). Stored preset ids are **0–253**.
- [ ] **TODO (Pico side, not done yet):** PRESET_DEFINE overwrites an existing slot silently. It should refuse
  unless the frame asks to overwrite (e.g. a flag byte, and a new error `0x0C` slot exists), so the Pico bounces
  back for permission. The controller GUI asks before overwriting, but only from its own library, which can be out of date.
- [ ] **POWERDOWN now returns to zero, reports positions and purges before sleeping.** Replies: ACK, `EVENT 0x13 <result> <bits>`, four `F6` position frames, `EVENT 0x11 <result> <wiper>`, `DONE`, then sleep. Allow up to ~75 s (return to zero ≤ 15 s, purge ≤ 60 s).
- [ ] **A battery-critical shutdown is an emergency shutdown:** `0xF1`, then `EVENT 0x11 …` (purge), then sleep. No return to zero and no position frames; positions are saved for the next boot.
- [ ] **Task-finished messages are status `0xE0` EVENT**, not DONE: info1 `0x10` sequence, `0x11` purge, `0x12` goto, `0x13` return-to-zero, `0x14` manual move ended. **DONE (0x02) is now only ever a command reply.**
- [ ] New ballast commands 0x0C (neutral), 0x0D (purge), 0x0E (goto, PID) and 0x0F (PID gains).
- [ ] Accept status `0xF3` (PID gain, three frames per 0x0F reply).
- [ ] A driver fault during a sequence, purge or goto sends `03 20 <bits>`, then that task's DONE frame (purge and goto report result 0x04 STOPPED). Expect both frames.
- [ ] Fault bit 7 (0x80) means the fault pins could not be read. Treat it like any other fault.
- [ ] **Every sequence is now followed by a log transfer.** After `EVENT 0x10`, expect `F4 <len u24>`, then exactly *len* raw bytes, then `F5 <crc hi> <crc lo>`. The parser must stop reading 5-byte frames for the raw block.
- [ ] Don't send anything between `EVENT 0x10` and `F5`. The Pico isn't reading the UART during the transfer. A new run sent too early gets `ERR_BUSY`.
- [ ] Decode the log with the format below. LOG_GET (0x10) re-sends the last one.
- [ ] Handle `03 21 <motor bits>` (slip protection cut a motor). The sequence continues on the other motors and still ends with `EVENT 0x10` and its log.
- [ ] **Boot order:** `F2` preset sync, `F7 <last shutdown> <restored>`, then `EVENT 0x13 <result> <motors not at zero>` once return-to-zero finishes. Until then, motion commands get `ERR_BUSY`.
- [ ] Result 0x06 at boot means at least one motor's zero is unknown (unclean shutdown). Those motors (bits in info3) were **not** moved. Use the manual controls to line them up, then SET_ZERO.
- [ ] **Manual buttons:** send MANUAL (0x11) forward / reverse / stop per motor. **While a motor should keep running, re-send its command about every 1 s.** It stops by itself 3 s after the last one (keepalive).
- [ ] Handle `EVENT 0x14 <reason> <motor>` + an `F6` frame: a manual motor stopped on its own (keepalive, slip, or pre-empted by an automatic task).
- [ ] `F7` info2 is now a **mask** of restored motors (was 0/1).

---

## Frame format (unchanged)

- **Host → Pico:** `cmd, payload…, chk`. Big-endian. `chk` = XOR of every preceding byte.
- **Pico → host:** always 5 bytes: `status, info1, info2, info3, chk` (`chk` = XOR of the four).
- Every valid command is answered with **ACK `01 00 00 00 01`** first, then its result.
- A bad checksum gets `03 01 00 00 02` and no ACK.

## Commands

| Code | Name | Size | Payload | Reply after ACK | Since |
|---|---|---|---|---|---|
| 0x01 | STOP | 3 | 1 pad byte | DONE | 1.0 |
| 0x02 | SET_MOTOR | 22 | `>BHHffffB`: m0_duty, m1_duty (u16), period, m0_latent, m1_latent, phase (f32) | DONE. Fills the temporary slot 0xFE | 1.0 (meaning changed in 2.0, see below) |
| 0x03 | SEQ_ADD | 22 | placeholder, ignored | DONE | 1.0 |
| 0x04 | SEQ_RUN | 4 | cycles (u16) | DONE `info1=0x10` when the sequence ends. Same as PRESET_RUN 0xFE | 1.0 |
| 0x05 | GET_STATUS | 3 | 1 pad byte | DONE `info1=running, info2=fault bits, info3=preset count` | 1.0 (info2/3 added in 2.0) |
| 0x06 | POWERDOWN | 3 | 1 pad byte | Normal shutdown: `EVENT 0x13`, 4 × `F6`, `EVENT 0x11`, then DONE, then the Pico sleeps (see Shutdown and boot) | 1.0 (sequence changed in 2.0) |
| 0x07 | PING | 3 | 1 pad byte | PONG `info1=major, info2=minor` | 1.0 (version added in 2.0) |
| **0x08** | **PRESET_DEFINE** | **47** | id (u8), period (f32), then for M1, M2, M3, M4: duty (u16), latent (f32), phase (f32) | DONE `info1=id, info2=preset count` | **2.0** |
| **0x09** | **PRESET_RUN** | **5** | id (u8), cycles (u16) | ACK, then `EVENT 0x10` when the sequence ends | **2.0** |
| **0x0A** | **PRESET_DELETE** | **3** | id (u8), `0xFF` = delete all | DONE `info1=id, info2=preset count` | **2.0** |
| **0x0B** | **PRESET_SYNC** | **3** | 1 pad byte | PRESET_SYNC `0xF2` (below) | **2.0** |
| **0x0C** | **BALLAST_NEUTRAL** | **5** | mode (u8), value (u16) | DONE `info1/info2 = stored value high/low, info3 = mode` | **2.0** |
| **0x0D** | **BALLAST_PURGE** | **3** | 1 pad byte | `EVENT 0x11 <result> <wiper hi>` when the purge ends | **2.0** |
| **0x0E** | **BALLAST_GOTO** | **5** | mode (u8: 0 neutral, 1 value), value (u16) | `EVENT 0x12 <result> <wiper hi>` when the move ends | **2.0** |
| **0x11** | **MANUAL** | **6** | motor (u8, 0–3, **4 = ballast**), action (u8: 0 stop, 1 forward, 2 reverse), speed (u16: 0 = default 10 %, ballast 40 %, else duty × 65535) | DONE `info1 = motor, info2 = action`; a stop is followed by that motor's `F6` (ballast: `F8`) | **2.0** (ballast **2.1**) |
| **0x12** | **SET_ZERO** | **3** | motor mask (u8, b0 M1 … b3 M4) | DONE `info1 = mask of motors with a known zero` | **2.0** |
| **0x13** | **GET_POSITIONS** | **3** | 1 pad byte | 4 × `F6`, `F8` (ballast, **2.1**), then DONE `info1 = known-zero mask` | **2.0** |
| **0x14** | **RETURN_TO_ZERO** | **3** | 1 pad byte | ACK, then `EVENT 0x13 <result> <motors not at zero>` when it ends. ERR_BUSY if a task runs | **2.1** |
| **0x15** | **SLIP_LIMIT** | **6** | mode (u8: 0 query, 1 set), motor (u8, 0–3), limit (u16, 0.1° units, 0 = off, max 6553.5°) | 4 × `F9` (all motors, after any change), then DONE `info1 = mode`. Set: ERR_BUSY during a task, 0x08 for motor > 3 | **2.1** |
| **0x17** | **DUTY_LIMIT** | **5** | mode (u8: 0 query, 1 set), limit (u16, duty × 65535; 10–100 %) | DONE `info1/info2 = limit u16 hi/lo, info3 = mode`. Set: ERR_BUSY during a motor-thread task, 0x08 below 10 % | **2.2** |
| **0x16** | **RTZ_PID** | **15** | mode (u8: 0 query, 1 set), kp, ki, kd (f32) | Three `F3` frames, info1 = `0x10` kp, `0x11` ki, `0x12` kd. One set of gains, used by all four motors | **2.1** |
| **0x10** | **LOG_GET** | **3** | 1 pad byte | Log transfer (`F4` … `F5`), or error 0x0B if there is no log | **2.0** |
| **0x0F** | **BALLAST_PID** | **15** | mode (u8: 0 query, 1 set), kp, ki, kd (f32) | Three `0xF3` frames with the gains now in force | **2.0** |

Python packing for the new commands (host side):

```python
import struct
def frame(fmt, *vals):
    body = struct.pack(fmt, *vals)
    chk = 0
    for b in body:
        chk ^= b
    return body + bytes([chk])

# motors = [(duty_u16, latent, phase)] for M1..M4
define = frame('>BBf' + 'Hff' * 4, 0x08, preset_id, period, *[x for m in motors for x in m])
run    = frame('>BBH', 0x09, preset_id, cycles)
delete = frame('>BB',  0x0A, preset_id)        # 0xFF deletes all
sync   = frame('>BB',  0x0B, 0)
neutral_capture = frame('>BBH', 0x0C, 0, 0)       # store the current wiper position
neutral_set     = frame('>BBH', 0x0C, 1, value)   # store a given raw value 0-65535
neutral_query   = frame('>BBH', 0x0C, 2, 0)       # read it back
purge  = frame('>BB',  0x0D, 0)
goto_neutral = frame('>BBH', 0x0E, 0, 0)
goto_value   = frame('>BBH', 0x0E, 1, value)            # raw 0-65535, clamped to 1000-64535
pid_query    = frame('>BBfff', 0x0F, 0, 0.0, 0.0, 0.0)
pid_set      = frame('>BBfff', 0x0F, 1, kp, ki, kd)     # each 0 to 655.35
```

### Ballast

The ballast position is the pot wiper, raw 0–65535 (0 = empty).

**BALLAST_NEUTRAL (0x0C)** stores the wiper value for neutral buoyancy in flash (`settings.json`). It survives power cycles.

| Mode | Action |
|---|---|
| 0 CAPTURE | Store the current wiper reading (averaged over 32 samples). The value field is ignored. |
| 1 SET | Store the value in the frame. |
| 2 QUERY | Report the stored value and change nothing. Returns error 0x0A if none is stored. |

CAPTURE and SET are refused with `ERR_BUSY` during a sequence or purge, because they write to flash.
BALLAST_GOTO mode 0 moves to it. The current wiper reading is in the `F8` frame from GET_POSITIONS.

**BALLAST_PURGE (0x0D)** drives the ballast toward empty on the motor thread, so STOP still works.
It ends with `EVENT 0x11 <result> <wiper high byte>`:

| Result | Meaning |
|---|---|
| 0x00 OK | Wiper reached zero (≤ 1000 raw, about 1.5 % of travel, kept off the hard stop) |
| 0x01 STALLED | Wiper fell less than 200 raw in 1 s (end stop, jam, drift or noise). The motor is turned off. |
| 0x02 TIMEOUT | Still not empty after 60 s |
| 0x03 WRONG_DIR | Wiper rose more than 1500 raw: `BALLAST_PURGE_SPEED` has the wrong sign |
| 0x04 STOPPED | STOP command or driver fault |

Purge is refused with `ERR_BUSY` while a sequence runs. Send STOP first.

**BALLAST_GOTO (0x0E)** moves the wiper to a target with a PID loop on the motor thread, so STOP still works.
Mode 0 uses the stored neutral (error 0x0A if none is stored), and mode 1 uses the value in the frame.
Targets are clamped to the soft limits, 1000–64535. The worm holds position unpowered, so the motor is braked
whenever the wiper is within ±300 raw of the target. The move ends once it has stayed there for 300 ms.
It ends with `EVENT 0x12 <result> <wiper high byte>`, using the same result codes as purge plus:

| Result | Meaning |
|---|---|
| 0x05 LIMIT | Wiper went more than 500 raw past a soft limit |

For goto, STALLED means the wiper moved less than 200 raw in 1 s while being driven, in either direction.
WRONG_DIR means the error grew by more than 1500 raw.

**BALLAST_PID (0x0F)** sets (mode 1) or queries (mode 0) the gains, which are saved in `settings.json`.
Gains are in units of output per unit of travel: an error of 10 % of travel with kp = 10 gives full output.
SET is refused with `ERR_BUSY` during a run, and with 0x08 for a negative gain or one of 655.36 or more.
Both modes reply with three frames, `F3 <index> <gain x100 high> <gain x100 low>`, for index 0 kp, 1 ki, 2 kd.

### Preset fields (per motor)

| Field | Range | Meaning |
|---|---|---|
| duty | 0–65535 | Stroke strength. 0 leaves that motor off for the whole preset. |
| latent | 0.0–1.0 | Fraction of each half-stroke the motor is left off. |
| phase | −1.0–1.0 | Shift in half-periods. 1.0 is the opposite stroke to a phase-0 motor. |

`period` is in seconds and must be > 0. All four motors share it.

### Stored presets and the temporary slot

Everything the Pico runs is a preset, so a sequence is always selected the same way: by id.

| Id | What it is | Saved to flash | In sync count/CRC | Define/delete during a run |
|---|---|---|---|---|
| 0–253 | Stored presets (up to 32) | Yes | Yes | No (`ERR_BUSY`) |
| **0xFE** | **Temporary slot for one-off sequences** | **No, lost at reset** | **No** | **Yes** (the running sequence keeps the old copy) |
| 0xFF | Not a preset. "All" for PRESET_DELETE | – | – | – |

- One-off 4-motor sequence: PRESET_DEFINE id 0xFE, then PRESET_RUN 0xFE.
- Legacy 2-channel path: SET_MOTOR fills 0xFE (through `seq_channels`), and SEQ_RUN runs it.
  An empty slot still gives the 1.0 error, 0x05.
- PRESET_DELETE 0xFE clears the temporary slot. PRESET_DELETE 0xFF clears the stored presets only.

## Status codes and errors

| Status | Name | info bytes | Since |
|---|---|---|---|
| 0x01 | ACK | – | 1.0 |
| 0x02 | DONE | per command | 1.0 |
| 0x03 | ERROR | info1 = error code (below) | 1.0 |
| **0xE0** | **EVENT** | **info1 = tag: 0x10 sequence, 0x11 purge, 0x12 goto, 0x13 return-to-zero, 0x14 manual end (unsolicited)** | **2.0** |
| 0x04 | PONG | info1/info2 = protocol major/minor | 1.0 (version added in 2.0) |
| 0xF0 | BAT_WARN | – (unsolicited) | 1.0 |
| 0xF1 | BAT_CRIT | – (unsolicited; starts an emergency shutdown: purge, save positions, sleep) | 1.0 (shutdown changed in 2.0) |
| **0xE0** + `0x10` | **EVENT, sequence finished** | info1 = 0x10 | **2.0** (was DONE 0x10 in 1.0) |
| **0xE0 + `0x11`** | **EVENT, purge finished** | **info2 = purge result, info3 = wiper high byte** | **2.0** |
| **0xE0 + `0x12`** | **EVENT, goto finished** | **info2 = result, info3 = wiper high byte** | **2.0** |
| **0xE0 + `0x14`** | **EVENT, manual motion ended on its own (unsolicited)** | **info2 = reason (0 stop, 1 keepalive timeout, 2 slip, 3 pre-empted, 4 soft limit [ballast, 2.1]), info3 = motor index (4 = ballast); followed by that motor's `F6` (ballast: `F8`)** | **2.0** |
| **0xE0 + `0x13`** | **EVENT, return-to-zero finished (unsolicited at boot; also during a normal shutdown)** | **info2 = result, info3 = motors NOT at zero (b0 M1 … b3 M4)** | **2.0** |
| **0xF6** | **POSITION** | **info1 = motor index 0–3 (b7 set = value clipped to i16), info2/info3 = encoder count (i16)** | **2.0** |
| **0xF7** | **BOOT** | **info1 = last shutdown (0 unclean, 1 normal, 2 emergency), info2 = mask of motors whose position was restored** | **2.0** |
| **0xF4** | **LOG_BEGIN** | **info1..info3 = byte count (u24). Exactly that many raw bytes follow, then LOG_END** | **2.0** |
| **0xF5** | **LOG_END** | **info1/info2 = CRC-16 of the raw bytes (same CRC as preset sync), info3 = 0** | **2.0** |
| **0xF3** | **PID_GAIN** | **info1 = gain index (0 kp, 1 ki, 2 kd; 0x10–0x12 for RTZ_PID), info2/info3 = gain x100 (u16)** | **2.0** (RTZ **2.1**) |
| **0xF8** | **BALLAST** | **info1 b0 = a neutral is stored, info2/info3 = wiper raw (u16)** | **2.1** |
| **0xF9** | **SLIP** | **info1 = motor 0–3, info2/info3 = slip limit in 0.1° (u16, 0 = off)** | **2.1** |
| **0xF2** | **PRESET_SYNC** | **info1 = preset count, info2/info3 = CRC-16 high/low** (unsolicited at boot, or a reply to 0x0B) | **2.0** |

| Error (info1) | Meaning | info2 | Since |
|---|---|---|---|
| 0x01 | Bad checksum | – | 1.0 |
| 0x02 | Frame could not be unpacked | – | 1.0 |
| 0x04 | Busy: a sequence is already running (also: define/delete during a run) | preset id where relevant | 1.0 (wider use in 2.0) |
| 0x05 | SEQ_RUN with no SET_MOTOR yet, or cycles = 0 | – | 1.0 |
| **0x06** | **Unknown preset id** | **id** | **2.0** |
| **0x07** | **Preset table full (32)** | **id** | **2.0** |
| **0x08** | **Bad value (period ≤ 0, cycles = 0, PRESET_DEFINE id 0xFF)** | **id** | **2.0** |
| **0x09** | **Changed in RAM but the flash save failed (preset or neutral)** | **id, where relevant** | **2.0** |
| **0x0A** | **Neutral QUERY before any neutral was stored** | – | **2.0** |
| **0x0B** | **LOG_GET with no log on the Pico** | – | **2.0** |
| 0x10 | Exception inside a command handler | command code | 1.0 |
| **0x20** | **Driver fault, unsolicited. All motors, ballast included, were stopped.** | **fault bits: b0 M1, b1 M2, b2 M3 or M4, b7 fault pins unreadable** | **2.0** |
| **0x21** | **Slip protection cut a motor (unsolicited, during a sequence)** | **motor bits: b0 M1 … b3 M4** | **2.0** |
| 0xFF | Unknown command | – | 1.0 |

---

## Shutdown and boot

| | Normal: POWERDOWN (0x06) | Emergency: battery critical |
|---|---|---|
| Frames sent | ACK, `EVENT 0x13`, 4 × `F6`, `EVENT 0x11`, `DONE` | `F1`, `EVENT 0x11` |
| Stop running sequence | Yes | Yes |
| Return drive motors to zero | **Yes** | **No** (saves energy) |
| Report positions to host | **Yes** (`F6` per motor, after return to zero) | No |
| Purge ballast | Yes | Yes |
| Save positions + shutdown type to `settings.json` | Yes | Yes |

**At boot** the Pico sends `F2` (preset sync), then `F7 <last shutdown> <restored>`. It restores the saved
positions and marks them used straight away, so after a later power cut the next boot sees an
unclean shutdown and doesn't trust stale positions. It then returns to zero:
after a normal shutdown that's only a quick check; after an emergency it's the recovery.

| `F7` info1 | Last shutdown | Positions restored? |
|---|---|---|
| 0 | Unclean (power cut, crash) | No: return-to-zero reports 0x06 and nothing moves |
| 1 | Normal | Yes (≈ zero) |
| 2 | Emergency | Yes (where the motors were left) |

Positions are only saved as valid if the Pico knew where zero was (restored at boot, or set with
`set_zero_here()`). After an unclean boot, the normal shutdown skips return-to-zero (0x06) and
saves the positions as not valid, so a bad zero is never carried forward.

**Return to zero** drives every motor to count 0 with a per-motor PID, all at once. It ends with
`EVENT 0x13 <result> <bits of motors not at zero>`:

| Result | Meaning |
|---|---|
| 0x00 OK | All motors within ±5 counts (~1°) of zero |
| 0x01 STALLED | A motor moved less than 10 counts in 0.5 s while driven. That motor is braked; the others continue |
| 0x02 TIMEOUT | Not settled after 15 s |
| 0x03 WRONG_DIR | A motor's error grew by 200 counts: motor or encoder direction is inverted |
| 0x04 STOPPED | STOP command or driver fault |
| 0x06 NO_POSITIONS | At least one motor's zero is unknown (not restored, not re-zeroed). **Those motors weren't moved**; the rest were |
| 0x07 OUT_OF_RANGE | A saved position was outside that motor's slip limit. That motor wasn't moved |

Zero is tracked **per motor** and carried across power cycles. SET_ZERO (0x12) redefines it for the
motors in a mask, and positions are saved as valid only for motors whose zero is known.

## Manual override (re-zeroing after an unclean shutdown)

Manual control runs in the comms thread and is meant for forward / reverse / stop buttons per motor.

1. MANUAL forward or reverse starts one motor at **10 % PWM** ("run slow"). A non-zero speed field
   overrides it, capped by the motor's duty limit. Several motors can run at once.
2. **Keepalive:** while a button is held (or latched on), re-send the same MANUAL command about every 1 s.
   If none arrives for 3 s, the motor stops and the Pico sends `EVENT 0x14 1 <motor>` + `F6`.
3. MANUAL stop brakes the motor and replies DONE + that motor's `F6` position.
4. When an actuator is lined up, send SET_ZERO with its bit. GET_POSITIONS shows all four positions and
   which zeros are known (for a display).

**Ballast (index 4, 2.1):** forward fills (wiper rises), reverse empties, at 40 % duty by default (the worm
drive does not turn at 10 %); a speed field overrides it, still capped at 65 %. The same 3 s keepalive applies.
There is no encoder, so instead of a slip limit it stops at the soft limits (1000 and 64535 raw) with
`EVENT 0x14 4 4` + `F8`. Starting toward a limit it is already past is refused with 0x08. Use it to find the
neutral point, then BALLAST_NEUTRAL capture (mode 0).

Safety: STOP and driver faults stop manual motors like any other. Slip protection applies, measured from
where each push started (`EVENT 0x14 2 <motor>`). MANUAL forward/reverse is refused with `ERR_BUSY` while a
sequence, purge, goto or return-to-zero runs, and starting one of those stops all manual motion first
(`EVENT 0x14 3 <motor>`). SET_ZERO is refused while a masked motor is moving.

## Sequence log

Every sequence (stored preset, temporary slot or legacy SEQ_RUN) records the four encoder counts
from start to stop. Once the sequence ends, the Pico sends `EVENT 0x10`, then saves the log to `seq_log.bin`
and streams it. A sequence ended by STOP or a fault is still logged, with the incomplete flag set.

**Interval:** 10 ms, stretched for long sequences so the whole run fits in 2000 samples
(for example, 16 ms for a 30 s run). A full log is about 40 KB, which takes about 3.5 s at 115200 baud.

**File / transfer layout** (big-endian):

| Field | Type | Notes |
|---|---|---|
| magic | 4 bytes | `SQLG` |
| version | u8 | 1 |
| n_motors | u8 | 4 |
| preset id | u8 | 0xFE for the temporary slot / legacy SEQ_RUN |
| flags | u8 | b0 ended early (STOP, fault, error), b1 buffer full before the end, b2 slip protection cut a motor |
| cycles | u16 | |
| interval_ms | u16 | |
| n_samples | u16 | |
| counts_per_output_rev | f32 | divide counts by this for output-shaft revolutions |
| period | f32 | seconds |
| samples | n × 20 bytes | t_ms (u32, since start), then M1–M4 counts (i32) |

The first sample is at t = 0 and the last is the position after the motors stopped.
Counts are absolute since the Pico powered up, so subtract the first sample for movement during the sequence.

```python
import struct, binascii

def read_log(read_exact):                 # read_exact(n) -> bytes from the serial port
    f = read_exact(5)
    assert f[0] == 0xF4
    raw = read_exact((f[1] << 16) | (f[2] << 8) | f[3])
    end = read_exact(5)
    assert end[0] == 0xF5 and (end[1] << 8 | end[2]) == binascii.crc_hqx(raw, 0xFFFF)
    (magic, ver, nm, pid, flags, cycles, interval, n,
     cpr, period) = struct.unpack('>4sBBBBHHHff', raw[:22])
    samples = [struct.unpack_from('>Iiiii', raw, 22 + 20 * k) for k in range(n)]
    return dict(preset=pid, flags=flags, cycles=cycles, interval_ms=interval,
                counts_per_rev=cpr, period=period), samples
```

## Preset sync procedure (host side)

At every boot the Pico reloads presets from flash and sends `F2 count crc_hi crc_lo chk` unsolicited.
The host can also ask at any time with PRESET_SYNC (0x0B).

1. Compute the CRC of the host's own table (below) and compare count + CRC.
2. If they match, nothing to do.
3. If they differ, send PRESET_DELETE `0xFF`, PRESET_DEFINE each preset, then PRESET_SYNC and confirm the match.

**CRC definition:** CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF, no reflection, no final XOR), over the presets in ascending id order, each packed as `struct.pack('>Bf' + 'Hff'*4, id, period, duty1, latent1, phase1, … duty4, latent4, phase4)`. An empty table gives `0xFFFF`.

```python
import binascii, struct
def presets_crc(presets):          # {id: (period, [(duty, latent, phase)] x 4)}
    data = b''.join(struct.pack('>Bf' + 'Hff' * 4, pid, period, *[x for m in motors for x in m])
                    for pid, (period, motors) in sorted(presets.items()))
    return binascii.crc_hqx(data, 0xFFFF)
```

Values are packed as 32-bit floats on both sides, so a host table holding 64-bit floats still
matches once packed. Store the values you sent, not values you recalculated.

---

## Change log

### 2026-11-10: protocol 2.2, firmware `robot_io.py`

**Affects the host** (additive)
- Added DUTY_LIMIT (0x17): drive-motor PWM limit for M1–M4, default **80 %**, saved in `settings.json`
  (`drive_max_duty`). It caps sequences (preset duties are clamped when the schedule is built, so the
  smooth-step ramps stay smooth), manual moves and return to zero. The ballast keeps its own 65 % cap.
  Reason: the switching simulation showed four loaded motors at 100 % draw ~4.6 A steady from the 5 A
  battery / boost; 80 % draws ~2.8 A.
- PONG reports (2, 2).

### 2026-11-10: protocol 2.1 (unchanged), firmware `robot_io.py`

**Affects the host (timing only; no frame changes)**
- Sequences now ramp every edge with the Abaqus SMOOTH STEP curve (`SMOOTH_STEP_S` = 80 ms, centred on
  the edge) instead of switching instantly. A run lasts up to one ramp longer, and logs show rounded
  strokes. At back-to-back reversals (latent 0) each stroke's travel drops by 0.156 × ramp × duty per side.

**Firmware only**
- The motor thread recomputes every motor's PWM each 2 ms (`SEQ_UPDATE_US`) from per-motor amplitude tables,
  replacing the old list of on/off events.
- `Motor.set` sets the duty to 0 before changing DIR, so no motor ever reverses under drive.

### 2026-11-09: protocol 2.1, firmware `robot_io.py`

**Affects the host** (additive; 2.0 hosts are unaffected apart from the extra `F8` in GET_POSITIONS)
- Added RETURN_TO_ZERO (0x14): on-demand return to zero, same routine and `EVENT 0x13` as at boot.
- Added SLIP_LIMIT (0x15) and status 0xF9: set / query each drive motor's slip limit, saved in `settings.json`.
  Replaces setting `slip_limit_deg` by hand in `RobotIO.__init__`.
- Added RTZ_PID (0x16): set / query the return-to-zero gains (one set for all four), saved in `settings.json`.
  Replies use `F3` with info1 0x10–0x12.
- MANUAL motor index 4 jogs the ballast, stopping at the soft limits (new end reason 4).
- Added status 0xF8 BALLAST (wiper reading + neutral-stored flag), sent by GET_POSITIONS and after a ballast manual stop.
- PONG reports (2, 1).

**Firmware only**
- An exception inside the return-to-zero thread now reports `03 10 14` (was `03 10 13`, which read as GET_POSITIONS).

### 2026-11-09: protocol 2.0, firmware `robot_io.py`

**Affects the host**
- UART moved to **GP12 (TX) / GP13 (RX)**. Was GP16 / GP17. Same 115200 8N1.
- Added PRESET_DEFINE (0x08), PRESET_RUN (0x09), PRESET_DELETE (0x0A), PRESET_SYNC (0x0B).
- Added status 0xF2 PRESET_SYNC, sent unsolicited at every boot.
- Added unsolicited driver-fault error `0x03 0x20 <bits>`. The Pico stops all motors when it sends it.
- Added error codes 0x06, 0x07, 0x08, 0x09.
- PING → PONG now returns the protocol version (2, 0) in info1/info2. Was 0, 0.
- GET_STATUS now returns fault bits in info2 and the preset count in info3. Were 0.
- SET_MOTOR's two channels now map to motors through `seq_channels` in the firmware. Default: m0 → M1, m1 → M2, and M3/M4 stay off.
- STOP now takes effect within about 2 ms during a sequence. Previously a motor could switch back on for one more step after STOP.
- Every run goes through a preset id. Id 0xFE is a RAM-only temporary slot for one-off sequences, and stored ids are 0–253.
  SET_MOTOR / SEQ_RUN now fill and run that slot. They behave as in 1.0.
- PRESET_DEFINE / PRESET_DELETE of stored presets return ERR_BUSY (0x04) while a sequence runs. The temporary slot can be changed at any time.
- Added BALLAST_NEUTRAL (0x0C): capture / set / query the neutral-buoyancy wiper value, saved in flash.
- Added BALLAST_PURGE (0x0D): drive to empty with stall, timeout and wrong-direction cut-offs. Ends with `EVENT 0x11 <result> <wiper hi>`.
- **POWERDOWN and the battery-critical shutdown now purge the ballast before sleeping.** POWERDOWN replies are ACK, purge DONE, then DONE (was ACK, DONE).
- Task-finished messages use the new status **0xE0 EVENT** (info1 = 0x10 sequence, 0x11 purge, 0x12 goto,
  0x13 return-to-zero, 0x14 manual end). In 1.0 the sequence end was `DONE 0x10`. Moved because command
  replies also carry data in info1: e.g. defining preset 16 replied `DONE 0x10 …`, the same bytes as
  "sequence finished".
- Added error 0x0A (no neutral stored). Error 0x09 now also covers the neutral setting.
- Added BALLAST_GOTO (0x0E): PID move to neutral or to a value, ending with `EVENT 0x12`. Adds result 0x05 LIMIT.
- Added BALLAST_PID (0x0F) and status 0xF3: set / query PID gains, saved in flash.
- Driver faults are raised as an exception (`DriverFault`) and checked inside every motion loop.
  A fault now ends a sequence, purge or goto within one loop step (2–20 ms), stops every motor
  including the ballast, sends `03 20 <bits>` once per occurrence, and then sends the task's DONE frame.
- Fault bit 7 (0x80): the fault pins could not be read (fail-safe, treated as a fault).
- An unexpected error inside a running task now stops all motors and sends `03 10 <cmd>`, then the
  task's DONE frame. Previously the motors could keep running.
- The power-off purge ignores drive-motor faults, so a fault cannot stop the vehicle surfacing.
- **Sequence logging:** every sequence records M1–M4 encoder counts (10 ms or coarser, up to 2000 samples).
  After `EVENT 0x10`, the log is saved to `seq_log.bin` and streamed as `F4 <len>`, raw bytes, `F5 <crc>`.
  Added LOG_GET (0x10), status 0xF4 / 0xF5 and error 0x0B. A new run is refused with ERR_BUSY until the log has been sent.
- **Driver slip protection:** per-motor `slip_limit_deg` (output-shaft degrees either side of the position at
  sequence start). Past it, only that motor is cut for the rest of the run, `03 21 <motor bits>` is sent once,
  and log flag b2 is set. **Disabled (None) on every motor until the limits are measured.** (2.1: set with SLIP_LIMIT.)
- Slip protection look-ahead: a motor is also cut if it *will* pass its limit within 20 ms at its current
  speed (`Motor.SLIP_LOOKAHEAD_S`), so it stops before the limit rather than after it.
- **Encoder positions persist:** saved to `settings.json` at every power-down, and restored at boot (one use only).
- **Return-to-zero at boot** (PID per motor), ending with the unsolicited `EVENT 0x13 <result> <bits>`. Adds results 0x06 and 0x07.
- **Two shutdown types.** Normal (POWERDOWN): return to zero, report positions (`F6` × 4), purge, save, DONE.
  Emergency (battery critical): purge, save positions, no return to zero. The type is saved and reported at
  boot in the new `F7` frame. Added status 0xF6 POSITION and 0xF7 BOOT.
- **Manual override:** MANUAL (0x11) forward / reverse / stop per drive motor at 10 % by default, with a 3 s
  keepalive; SET_ZERO (0x12) per motor mask; GET_POSITIONS (0x13). Added EVENT tag 0x14.
- **Zero is per motor.** Return-to-zero moves only motors with a known zero (others reported in info3 with 0x06),
  `settings.json` stores `positions_valid` as a list, and `F7` info2 is a mask of restored motors.

**Firmware only (no host impact)**
- Drivers changed to Pololu G2 (PWM + DIR per motor, 20 kHz). 4 drive motors + ballast.
- Ballast PWM hard-capped at 65 % duty.
- Encoders on PIO (x4 quadrature), read about every 2 ms during sequences and every 10 ms when idle.
- Battery sense moved to GP27. Same thresholds (warn 11.0 V, shutdown 10.2 V).
- Presets persist in flash (`presets.json`), and the ballast neutral in `settings.json`.
- Purge and goto thresholds are constants in `robot_io.py` (`PURGE_*`, `GOTO_*`, `BALLAST_PURGE_SPEED`). Tune them to the real ballast.
- Default PID gains (15, 1.0, 0.2) are placeholders until tuned.

### Template for the next entry

```
### YYYY-MM-DD: protocol X.Y
**Affects the host**
- …
**Firmware only (no host impact)**
- …
```
Bump the minor version for additions the host can ignore. Bump the major version when an existing
frame, code or behaviour changes, and update `PROTOCOL_VERSION` in `robot_io.py` to match.
