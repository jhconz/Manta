# Quad G2 controller firmware (`robot_io.py`)

MicroPython firmware for the Raspberry Pi Pico on the Quad G2 signal board. It drives four
belt-driven actuator motors and a ballast motor, takes commands over UART from a host, and
handles start-up, shutdown and the safety cut-offs on its own.

- **Firmware:** `robot_io.py` (single file, class `RobotIO`), about 1,900 lines
- **UART protocol:** version **2.2**. Full byte-level reference and change history are in `PROTOCOL_CHANGES.md`
- **Status:** tested in simulation only (stubbed hardware). **Not yet run on a Pico.**

---

## Hardware

| Item | Part | Notes |
|---|---|---|
| Controller | Raspberry Pi Pico (RP2040), MicroPython | Powered over USB from a 5 V buck |
| Drive motors M1–M4 | Pololu 25D HP #5724 + 48 CPR encoder | Assumed 34.014:1, ≈1632.7 counts per output rev (**confirm**) |
| Drivers | Pololu G2 24v13 ×4 (+1 for the ballast) | PWM/DIR, 20 kHz. SLP left open (awake) |
| Ballast | JGY370 12 V worm motor + B103 slide pot | PWM hard-capped at 65 % (≈10.4 V average on 16 V) |
| Power | 4S LiFePO4 → XL6019 boost to 16 V | Battery sensed through a 47k/10k divider |

### Pin map

| Pico pins | Function |
|---|---|
| GP0 / GP1 / GP2 | M1 PWM / DIR / FLT |
| GP3 / GP4 | M1 encoder A / B (PIO SM0) |
| GP5 / GP6 / GP7 | M2 PWM / DIR / FLT |
| GP8 / GP9 | M2 encoder A / B (PIO SM1) |
| GP10 | Shared FLT for M3 + M4 (open-drain wire-OR) |
| GP11 | **Spare** |
| GP12 / GP13 | UART0 TX / RX (115200 8N1) |
| GP14 / GP15 | Ballast PWM / DIR (ballast FLT not connected) |
| GP16 / GP17 | M3 DIR / PWM |
| GP18 / GP19 | M3 encoder A / B (PIO SM2) |
| GP20 / GP21 | M4 encoder A / B (PIO SM3) |
| GP22 / GP26 | M4 DIR / PWM |
| GP27 (ADC1) | Battery sense |
| GP28 (ADC2) | Ballast pot wiper (pot across 3V3 / AGND) |

Encoder lines pass through 20k/22k dividers (5 V → ≈2.6 V). PWM slices: M1 0A, M2 2B, M3 0B, M4 5A,
ballast 7A. M1 and M3 share slice 0, so they share a frequency but have independent duty.

---

## How it runs

| Core | Runs | Owns |
|---|---|---|
| **Core 0, main loop** (`RobotIO.run`) | UART parsing and replies, fault checks (20 ms), battery checks (200 ms), manual override, encoder reads while idle, writing and streaming logs, all flash writes | Everything when no task is running |
| **Core 1, motor thread** | One task at a time: sequence, ballast purge, ballast goto, or return-to-zero | Motors and encoders while its task runs |

- Only one motor-thread task runs at a time. Others are refused with `ERR_BUSY`.
- **Flash is never written while a motor-thread task runs:** RP2040 flash writes stall both cores. That's why preset, neutral and gain changes are refused mid-run, and why the sequence log is kept in RAM until the run ends.
- Encoders are read from one core at a time (the PIO FIFO can't be shared).

---

## Lifecycle

### Boot
1. Load presets and settings from flash, and send `F2` (preset count + CRC) so the host can resync.
2. Restore the drive-motor positions saved at the last clean shutdown, and send `F7` (last shutdown type + restored-motor mask). The saved positions are marked *used* immediately.
3. **Return to zero** (motor thread, PID per motor): every motor with a known zero drives to count 0. It ends with `EVENT 0x13`.

### Shutdown

| | Normal (`POWERDOWN` command) | Emergency (battery ≤ 10.2 V for ~2 s) |
|---|---|---|
| Stop running task | ✓ | ✓ |
| Return to zero | ✓ | ✗ (saves energy) |
| Report positions to host | ✓ (`F6` × 4) | ✗ |
| Purge ballast | ✓ | ✓ |
| Save positions + shutdown type | ✓ | ✓ |
| Then | `DONE`, deep sleep | deep sleep |

After a power cut or crash, nothing is saved. The next boot reports an unclean shutdown, and **no motor moves** until it is re-zeroed manually.

---

## Features

### Sequences and presets
- Every motion runs as a **preset**: period (s), plus per motor a duty (0–65535), a *latent* fraction (part of each half-stroke left off) and a *phase* (−1…1 half-periods; 1.0 = opposite stroke).
- Waveform per motor: a quarter stroke forward, alternating half strokes, then a quarter stroke forward, repeated for N cycles.
- **Smooth-step edges:** every on, off and reverse edge follows the Abaqus SMOOTH STEP amplitude curve,
  `a0 + (a1 − a0)·ξ³(10 − 15ξ + 6ξ²)`, instead of jumping. It has zero slope and zero curvature at both ends.
  - Each ramp lasts `SMOOTH_STEP_S` (80 ms), centred on the original edge. It is shortened where two edges are closer than that.
  - The PWM is recomputed every 2 ms. The duty passes through zero before DIR changes, and `Motor.set` also zeroes the duty before any DIR change.
  - **Travel:** strokes next to off-time (latent > 0) keep exactly the same travel. At a back-to-back reversal (latent 0) the curve crosses zero mid-ramp, so each stroke loses 0.156 × ramp × duty per reversal side: about 8 % of a 0.3 s half-stroke with 80 ms ramps. The run still ends where it started. Raise duty or period slightly, or shorten the ramp, to compensate.
  - A run takes up to one ramp (80 ms) longer than before. Set `SMOOTH_STEP_S = 0` to get the old square wave back.
- **Stored presets:** ids 0–253, up to 32, saved in `presets.json`, synced to the host by count + CRC at boot.
- **Temporary slot 0xFE:** RAM only, for one-off sequences. It can be redefined mid-run. The legacy 2-channel `SET_MOTOR` / `SEQ_RUN` commands fill and run this slot (`seq_channels` maps the two channels to motors; default M1 and M2).

### Sequence log
- Every sequence records time + all four encoder counts: every 10 ms, or coarser so the whole run fits in 2,000 samples (40 KB RAM, allocated once).
- After the sequence's `DONE`, the log is saved to `seq_log.bin` and streamed: `F4 <len>`, raw bytes, `F5 <CRC>`. That's about 3.5 s for a full log at 115200. `LOG_GET` re-sends it.
- Flags mark runs that ended early, filled the buffer, or had a motor cut by slip protection.

### Ballast
- **Neutral:** capture, set or query the wiper value for neutral buoyancy (saved in `settings.json`).
- **Purge:** drive to empty at the capped duty. Stops at zero, on a stall, on timeout, on wrong direction, or on STOP.
- **Goto (PID):** to neutral or to any value, within soft limits. Brakes inside a ±300 band (the worm holds position unpowered). PID gains are settable over UART and saved.
- **Manual jog:** MANUAL index 4 fills / empties at 40 % with the same keepalive, stopping at the soft limits. GET_POSITIONS reports the wiper (`F8`), so the host can show it while finding neutral.

### Drive-motor positions and zero
- Zero is tracked **per motor** and kept across clean power cycles.
- **Return to zero:** a PID per motor, all at once, ±5 counts (≈1°). Skips and reports motors with an unknown zero or outside their slip limit. Runs at boot, at a normal shutdown, and on demand (RETURN_TO_ZERO, 0x14). Gains settable over UART (RTZ_PID, 0x16) and saved.
- **Manual override** (comms thread): forward / reverse / stop per motor at 10 % by default, with an optional speed. A **3 s keepalive** applies, so the host re-sends about every 1 s while a button is held. `SET_ZERO` (per motor mask) and `GET_POSITIONS` support re-zeroing after an unclean shutdown.

### Safety layers

| Layer | Trigger | Action |
|---|---|---|
| Driver fault | Any FLT line low, or the fault pins unreadable | `DriverFault` raised in every loop: stop **all** motors, report `03 20 <bits>` once |
| Slip protection | Shaft past `slip_limit_deg` (or will be within 20 ms) from the start of the run or push | Cut that motor only, report `03 21` |
| STOP command | Host | Stop everything within ~2 ms |
| Battery | ≤ 11.0 V warning; ≤ 10.2 V for 10 checks | `F0` warning; `F1` + emergency shutdown |
| Ballast purge / goto | Stall, timeout, wrong direction, soft limit | Brake, report the result |
| Return to zero | Stall, wrong direction, timeout | Brake that motor, report it |
| Manual keepalive | No command for 3 s | Stop that motor, `EVENT 0x14` |
| Thread crash | Any unexpected exception in a task | Stop all motors, report `03 10 <cmd>` |
| Ballast cap | Always | Duty never above 65 % |

---

## Files on the Pico

| File | Contents | Written |
|---|---|---|
| `robot_io.py` | Firmware (run as `main.py`, or import it from `main.py`) | By you |
| `presets.json` | Stored presets | On preset define / delete |
| `settings.json` | Ballast neutral, ballast and return-to-zero PID gains, slip limits, drive PWM limit, encoder counts, per-motor validity, last shutdown type | On setting changes, at boot (marks positions used), at shutdown |
| `seq_log.bin` | Last sequence log | After each sequence |

Every write goes to a temp file and is then renamed, so a reset mid-write keeps the old file.

---

## Configuration and tuning

All values are class constants in `robot_io.py`. **Bold** values are placeholders that need measuring on the real hardware.

| Area | Constant | Default | Notes |
|---|---|---|---|
| Motors | `GEAR_RATIO` | **34.014** | Confirm against the #5724 listing |
| | `drive_max_duty` (`DRIVE_MAX_DUTY_DEFAULT`) | **0.80** | Drive PWM limit for all motion. Settable over UART (DUTY_LIMIT) / the GUI's SETTINGS tab; saved. 80 % keeps four loaded motors inside the 5 A battery / boost budget in water |
| | `SMOOTH_STEP_S` | **0.080 s** | Ramp time per sequence edge. Longer = gentler on the 16 V rail, but less travel at reversals. 0 = square wave |
| | `invert` / `enc_invert` per motor | False | Set so positive speed means positive counts |
| | `slip_limit_deg` per motor | **None (off)** | Set from logged peak angles, over UART (SLIP_LIMIT) or the GUI's SETTINGS tab; saved |
| | `Motor.SLIP_LOOKAHEAD_S` | **0.020** | Match the real coast-down after a cut |
| Ballast | `BALLAST_PURGE_SPEED` (sign) | **−1.0** | Flip it if the first purge reports WRONG_DIR |
| | `PURGE_STALL_DELTA` / `_MS` | 200 raw / 1 s | Must be slower than the real stroke speed |
| | `PURGE_TIMEOUT_MS`, `GOTO_TIMEOUT_MS` | 60 s | Longer than a full stroke |
| | `BALLAST_PID_DEFAULT` | **(15, 1.0, 0.2)** | Also settable over UART |
| | `GOTO_MIN_OUT`, `GOTO_TOL_RAW` | **0.15**, 300 | Stiction, precision |
| Return to zero | `RTZ_PID_DEFAULT` | **(4.0, 0.5, 0.05)** | Also settable over UART (RTZ_PID); saved |
| | `RTZ_MIN_OUT`, `RTZ_TOL_COUNTS` | **0.08**, 5 | |
| Manual | `MANUAL_DEFAULT_DUTY`, `MANUAL_TIMEOUT_MS` | 0.10, 3000 | `None` disables the keepalive |
| | `BALLAST_MANUAL_DUTY` | **0.40** | Lowest duty that reliably turns the worm drive |
| Battery | `DIVIDER_R1/R2`, `V_OFFSET` | 46.4k / 9.8k, 0.20 V | Measured values |
| | `V_WARNING`, `V_SHUTDOWN` | 11.0 V, 10.2 V | 2.75 / 2.55 V per cell |
| Comms | UART baud | 115200 | Raise it on both ends to shorten log transfers |

---

## UART at a glance

Host → Pico: `cmd, payload…, XOR checksum`. Pico → host: 5-byte frames `status, info1, info2, info3, chk`,
except log transfers. Every valid command is ACKed first. **Full layouts are in `PROTOCOL_CHANGES.md`.**

| Code | Command | | Code | Command |
|---|---|---|---|---|
| 0x01 | STOP | | 0x0B | PRESET_SYNC |
| 0x02 | SET_MOTOR (legacy) | | 0x0C | BALLAST_NEUTRAL |
| 0x03 | SEQ_ADD (placeholder) | | 0x0D | BALLAST_PURGE |
| 0x04 | SEQ_RUN (legacy) | | 0x0E | BALLAST_GOTO |
| 0x05 | GET_STATUS | | 0x0F | BALLAST_PID |
| 0x06 | POWERDOWN | | 0x10 | LOG_GET |
| 0x07 | PING (→ version) | | 0x11 | MANUAL |
| 0x08 | PRESET_DEFINE | | 0x12 | SET_ZERO |
| 0x09 | PRESET_RUN | | 0x13 | GET_POSITIONS |
| 0x0A | PRESET_DELETE | | 0x14 | RETURN_TO_ZERO |
| | | | 0x15 | SLIP_LIMIT |
| | | | 0x16 | RTZ_PID |
| | | | 0x17 | DUTY_LIMIT |

Unsolicited from the Pico: `F2` sync and `F7` boot info at start-up; `E0` EVENT (tags 0x10 / 0x11 / 0x12 / 0x13 / 0x14)
when tasks end; `F0` / `F1` battery; `03 20` fault; `03 21` slip; log transfers.

---

## First power-up checklist

1. **Encoders:** turn each motor by hand and confirm `GET_POSITIONS` changes, then set `enc_invert` so that MANUAL forward gives positive counts.
2. **Faults:** pull each FLT line low and confirm `03 20` with the right bit, and that all motors stop.
3. **Ballast direction:** run one purge. If it reports WRONG_DIR (0x03), flip the sign of `BALLAST_PURGE_SPEED`.
4. **Ballast stall thresholds:** time a full stroke and check it's well inside the stall and timeout settings.
5. **Zero:** jog each actuator to its mark and send `SET_ZERO 0x0F`. Then `POWERDOWN`, boot, and check `F7` reports restored `1111`.
6. **Back-drive check:** mark a shaft, power down for a while, boot, and compare after return-to-zero.
7. **Tune PIDs:** ballast goto first (over UART), then return-to-zero.
8. **Slip limits:** run your sequences, read peak angles from the logs, then set them on the GUI's SETTINGS tab.
9. **Battery:** compare `GET_STATUS` / BAT warnings against a meter at a few voltages.

---

## Open items and possible gaps

### Must verify on hardware
- **The PIO quadrature decoder** relies on being padded to exactly 32 instructions so it loads at address 0 of PIO0. Confirm the counts are right, and that nothing else is loaded into PIO0 first.
- **What `machine.deepsleep()` does on your MicroPython build**, and how the Pico wakes (power switch? reset?). The Pico sleeping does **not** cut power: the boost converter, drivers and buck stay on the battery until the switch is turned off, so a "powered down" robot still drains the pack.
- **Driving `_thread` and PWM from core 1, and UART writes from both cores,** under the real MicroPython port.
- **Positions only survive a power-down if nothing moves while it's off.** The spur gearboxes aren't self-locking, so belt tension may back-drive them.

### Placeholders still to tune
All PID gains, the minimum outputs, the stall thresholds, the ballast direction sign, the slip limits and the look-ahead (see the tuning table).

### Not implemented (candidates)
- **Hardware watchdog (`machine.WDT`):** if the firmware hangs mid-sequence, nothing stops the motors. Probably the most important gap.
- **Drive-motor stall detection during sequences:** a jammed actuator draws about 1.8 A until the sequence ends; the G2's 30 A limit never trips. The encoder speed could be compared with the commanded speed.
- ~~Acceleration ramps~~: done (smooth-step edges). **Verify on hardware** that 80 ms is enough to keep the 16 V rail inside the TVS and boost limits when all four reverse together, using a scope on the rail.
- **Host link-loss detection** for automatic motion. Only manual motion has a keepalive; a sequence runs to completion if the host disappears.
- **Return-to-zero at boot moves the motors without a host command.** Consider whether that's safe out of the water or during handling, or whether boot should wait for a command.
- **UART commands not yet added:** manual default speed. (Slip limits, return-to-zero gains and on-demand return-to-zero were added in 2.1.)
- **Current sensing:** CS pins aren't wired, since there are no free ADC pins.
- **`SEQ_ADD` (0x03)** is still an empty placeholder.
- **Preset overwrite permission:** PRESET_DEFINE overwrites an existing slot silently. Make the Pico refuse unless
  the frame asks to overwrite, so it bounces back for permission. The GUI currently checks only its own library.
- Ballast purge/goto runs aren't logged; only sequences are.

### Known trade-offs
- **The emergency shutdown runs the ballast purge on a nearly flat battery.** Surfacing is the priority, but the purge could brown out the boost before it finishes.
- **M3, M4 and the ballast share one fault line,** so you can't tell which of them faulted.
- **The main loop isn't reading the UART during a log transfer** (about 3.5 s), so the host must wait for `F5`.
- **Presets are capped at 32**, and the RAM log at 2,000 samples. Long sequences get a coarser sample interval.
